export const AUTHENTICATE = 'AUTHENTICATE';

export const GET_POSTS = 'GET_POSTS';

export const UPDATE_TITLE = 'UPDATE_TITLE';
export const UPDATE_BODY = 'UPDATE_BODY';
export const SAVE_POST = 'SAVE_POST';
