import React from 'react';
import { Link } from 'react-router-dom';

export default function FeedLink() {
  return (
    <div>
      <Link to="/feed">Go to feed</Link>
    </div>
  );
}
